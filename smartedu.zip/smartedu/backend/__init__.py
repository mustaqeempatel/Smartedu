# SmartEdu backend package
